import { useState } from "react";
import "./App.css";
import Header from "./Components/Header/Header";
import Home from "./Components/Home/Home";
import Products from "./Components/Products/Products";
import Contact from "./Components/Contact/Contact";
import Layout from "./Components/Layout";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Details from "./Components/Detail/Details";
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="products/:name" element={<Products />} />
            <Route path="contact" element={<Contact />} />
            <Route path="products/detail/:id" element={<Details />} />

          </Route>
        </Routes>
      </BrowserRouter> 
    
    </>
  );
}

export default App;
